<%@ page language="java"
    contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ taglib prefix="c"
    uri="http://java.sun.com/jsp/jstl/core"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Catálogo de libros</title>

<link rel="stylesheet"
    href="${pageContext.request.contextPath}/css/estilos.css">
</head>

<body>

    <nav class="menu">
        <strong>Biblioteca Digital UNTEC</strong>

        <a href="${pageContext.request.contextPath}/libros">
            Libros
        </a>

        <a href="${pageContext.request.contextPath}/prestamos">
            Préstamos
        </a>

        <a href="${pageContext.request.contextPath}/logout">
            Cerrar sesión
        </a>
    </nav>

    <main class="contenedor">

        <h1>Catálogo de libros</h1>

        <p>
            Bienvenida,
            <strong>
                <c:out value="${sessionScope.usuario.nombre}"/>
            </strong>
        </p>

        <a class="boton"
           href="${pageContext.request.contextPath}/libros?accion=nuevo">
            Agregar libro
        </a>

        <c:if test="${empty libros}">
            <p>No existen libros registrados.</p>
        </c:if>

        <c:if test="${not empty libros}">

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Título</th>
                        <th>Autor</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>

                    <c:forEach var="libro" items="${libros}">

                        <tr>
                            <td>
                                <c:out value="${libro.idLibro}"/>
                            </td>

                            <td>
                                <c:out value="${libro.titulo}"/>
                            </td>

                            <td>
                                <c:out value="${libro.autor}"/>
                            </td>

                            <td>
                                <c:choose>
                                    <c:when test="${libro.disponible}">
                                        Disponible
                                    </c:when>

                                    <c:otherwise>
                                        Prestado
                                    </c:otherwise>
                                </c:choose>
                            </td>

                            <td>
                                <a href="${pageContext.request.contextPath}/libros?accion=editar&id=${libro.idLibro}">
                                    Editar
                                </a>

                                |

                                <a href="${pageContext.request.contextPath}/libros?accion=eliminar&id=${libro.idLibro}"
                                   onclick="return confirm('¿Eliminar este libro?');">
                                    Eliminar
                                </a>
                            </td>
                        </tr>

                    </c:forEach>

                </tbody>
            </table>

        </c:if>

    </main>

</body>
</html>