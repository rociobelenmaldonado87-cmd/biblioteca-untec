<%@ page language="java"
    contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Biblioteca Digital UNTEC</title>

<link rel="stylesheet"
    href="${pageContext.request.contextPath}/css/estilos.css">
</head>

<body class="pagina-login">

    <main class="tarjeta-login">

        <h1>Biblioteca Digital UNTEC</h1>

        <p class="subtitulo">
            Sistema de gestión de biblioteca
        </p>

        <p class="mensaje-error">${error}</p>

        <form action="${pageContext.request.contextPath}/login"
              method="post">

            <label for="correo">Correo electrónico</label>

            <input type="email"
                   id="correo"
                   name="correo"
                   placeholder="Ingrese su correo"
                   required>

            <label for="clave">Contraseña</label>

            <input type="password"
                   id="clave"
                   name="clave"
                   placeholder="Ingrese su contraseña"
                   required>

            <button type="submit">
                Iniciar sesión
            </button>

        </form>

        <p class="datos-prueba">
            Usuario de prueba: admin@untec.cl
        </p>

    </main>

</body>
</html>