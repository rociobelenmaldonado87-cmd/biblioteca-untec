<%@ page language="java"
    contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ taglib prefix="c"
    uri="http://java.sun.com/jsp/jstl/core"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">

<title>
    <c:choose>
        <c:when test="${empty libro}">
            Agregar libro
        </c:when>
        <c:otherwise>
            Editar libro
        </c:otherwise>
    </c:choose>
</title>

<link rel="stylesheet"
    href="${pageContext.request.contextPath}/css/estilos.css">
</head>

<body>

    <nav class="menu">
        <strong>Biblioteca Digital UNTEC</strong>

        <a href="${pageContext.request.contextPath}/libros">
            Volver al catálogo
        </a>
    </nav>

    <main class="contenedor">

        <div class="formulario">

            <h1>
                <c:choose>
                    <c:when test="${empty libro}">
                        Agregar libro
                    </c:when>
                    <c:otherwise>
                        Editar libro
                    </c:otherwise>
                </c:choose>
            </h1>

            <form action="${pageContext.request.contextPath}/libros"
                  method="post">

                <input type="hidden"
                       name="idLibro"
                       value="${libro.idLibro}">

                <label for="titulo">Título</label>

                <input type="text"
                       id="titulo"
                       name="titulo"
                       value="${libro.titulo}"
                       required>

                <label for="autor">Autor</label>

                <input type="text"
                       id="autor"
                       name="autor"
                       value="${libro.autor}"
                       required>

                <label for="disponible">Estado</label>

                <select id="disponible"
                        name="disponible">

                    <c:choose>

                        <c:when test="${empty libro or libro.disponible}">
                            <option value="true" selected>
                                Disponible
                            </option>
                            <option value="false">
                                Prestado
                            </option>
                        </c:when>

                        <c:otherwise>
                            <option value="true">
                                Disponible
                            </option>
                            <option value="false" selected>
                                Prestado
                            </option>
                        </c:otherwise>

                    </c:choose>

                </select>

                <button type="submit">
                    Guardar libro
                </button>

            </form>

        </div>

    </main>

</body>
</html>