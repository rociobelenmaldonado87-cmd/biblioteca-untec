<%@ page language="java"
    contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ taglib prefix="c"
    uri="http://java.sun.com/jsp/jstl/core"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Préstamos</title>

<link rel="stylesheet"
    href="${pageContext.request.contextPath}/css/estilos.css">
</head>

<body>

    <nav class="menu">
        <strong>Biblioteca Digital UNTEC</strong>

        <a href="${pageContext.request.contextPath}/libros">
            Libros
        </a>

        <a href="${pageContext.request.contextPath}/prestamos">
            Préstamos
        </a>

        <a href="${pageContext.request.contextPath}/logout">
            Cerrar sesión
        </a>
    </nav>

    <main class="contenedor">

        <h1>Gestión de préstamos</h1>

        <a class="boton"
           href="${pageContext.request.contextPath}/prestamos?accion=nuevo">
            Registrar préstamo
        </a>

        <c:if test="${empty prestamos}">
            <p>No existen préstamos registrados.</p>
        </c:if>

        <c:if test="${not empty prestamos}">

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Usuario</th>
                        <th>Libro</th>
                        <th>Fecha préstamo</th>
                        <th>Fecha devolución</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>

                    <c:forEach var="prestamo"
                               items="${prestamos}">

                        <tr>
                            <td>
                                <c:out value="${prestamo.idPrestamo}"/>
                            </td>

                            <td>
                                <c:out value="${prestamo.nombreUsuario}"/>
                            </td>

                            <td>
                                <c:out value="${prestamo.tituloLibro}"/>
                            </td>

                            <td>
                                <c:out value="${prestamo.fechaPrestamo}"/>
                            </td>

                            <td>
                                <c:out value="${prestamo.fechaDevolucion}"/>
                            </td>

                            <td>
                                <c:out value="${prestamo.estado}"/>
                            </td>

                            <td>

                                <c:if test="${prestamo.estado == 'PRESTADO'}">

                                    <a href="${pageContext.request.contextPath}/prestamos?accion=devolver&idPrestamo=${prestamo.idPrestamo}&idLibro=${prestamo.idLibro}">
                                        Devolver
                                    </a>

                                    |
                                </c:if>

                                <a href="${pageContext.request.contextPath}/prestamos?accion=eliminar&idPrestamo=${prestamo.idPrestamo}&idLibro=${prestamo.idLibro}"
                                   onclick="return confirm('¿Eliminar este préstamo?');">
                                    Eliminar
                                </a>

                            </td>
                        </tr>

                    </c:forEach>

                </tbody>
            </table>

        </c:if>

    </main>

</body>
</html>