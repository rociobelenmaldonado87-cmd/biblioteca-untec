<%@ page language="java"
    contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ taglib prefix="c"
    uri="http://java.sun.com/jsp/jstl/core"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Registrar préstamo</title>

<link rel="stylesheet"
    href="${pageContext.request.contextPath}/css/estilos.css">
</head>

<body>

    <nav class="menu">
        <strong>Biblioteca Digital UNTEC</strong>

        <a href="${pageContext.request.contextPath}/prestamos">
            Volver a préstamos
        </a>
    </nav>

    <main class="contenedor">

        <div class="formulario">

            <h1>Registrar préstamo</h1>

            <p>
                Selecciona uno de los libros disponibles.
            </p>

            <form action="${pageContext.request.contextPath}/prestamos"
                  method="post">

                <label for="idLibro">Libro</label>

                <select id="idLibro"
                        name="idLibro"
                        required>

                    <option value="">
                        Seleccione un libro
                    </option>

                    <c:forEach var="libro"
                               items="${libros}">

                        <c:if test="${libro.disponible}">

                            <option value="${libro.idLibro}">

                                <c:out value="${libro.titulo}"/>

                                -

                                <c:out value="${libro.autor}"/>

                            </option>

                        </c:if>

                    </c:forEach>

                </select>

                <button type="submit">
                    Registrar préstamo
                </button>

            </form>

        </div>

    </main>

</body>
</html>