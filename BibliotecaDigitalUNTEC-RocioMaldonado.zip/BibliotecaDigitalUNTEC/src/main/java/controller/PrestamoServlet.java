package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.LibroDAO;
import dao.PrestamoDAO;
import model.Libro;
import model.Prestamo;
import model.Usuario;

@WebServlet("/prestamos")
public class PrestamoServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private final PrestamoDAO prestamoDAO =
            new PrestamoDAO();

    private final LibroDAO libroDAO =
            new LibroDAO();

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession sesion = request.getSession(false);

        if (sesion == null
                || sesion.getAttribute("usuario") == null) {

            response.sendRedirect("index.jsp");
            return;
        }

        String accion = request.getParameter("accion");

        if (accion == null) {
            accion = "listar";
        }

        switch (accion) {

        case "nuevo":

            List<Libro> libros = libroDAO.listar();

            request.setAttribute("libros", libros);

            request.getRequestDispatcher(
                    "prestamo-formulario.jsp")
                    .forward(request, response);

            break;

        case "devolver":

            int idPrestamo = Integer.parseInt(
                    request.getParameter("idPrestamo"));

            int idLibro = Integer.parseInt(
                    request.getParameter("idLibro"));

            prestamoDAO.devolver(idPrestamo, idLibro);

            response.sendRedirect("prestamos");

            break;

        case "eliminar":

            int prestamoEliminar = Integer.parseInt(
                    request.getParameter("idPrestamo"));

            int libroLiberar = Integer.parseInt(
                    request.getParameter("idLibro"));

            prestamoDAO.eliminar(
                    prestamoEliminar, libroLiberar);

            response.sendRedirect("prestamos");

            break;

        default:

            List<Prestamo> prestamos =
                    prestamoDAO.listar();

            request.setAttribute(
                    "prestamos", prestamos);

            request.getRequestDispatcher("prestamos.jsp")
                    .forward(request, response);

            break;
        }
    }

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        HttpSession sesion = request.getSession(false);

        if (sesion == null
                || sesion.getAttribute("usuario") == null) {

            response.sendRedirect("index.jsp");
            return;
        }

        Usuario usuario =
                (Usuario) sesion.getAttribute("usuario");

        int idLibro = Integer.parseInt(
                request.getParameter("idLibro"));

        prestamoDAO.registrar(
                usuario.getIdUsuario(), idLibro);

        response.sendRedirect("prestamos");
    }
}