package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.LibroDAO;
import model.Libro;

@WebServlet("/libros")
public class LibroServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private final LibroDAO libroDAO = new LibroDAO();

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession sesion = request.getSession(false);

        if (sesion == null
                || sesion.getAttribute("usuario") == null) {

            response.sendRedirect("index.jsp");
            return;
        }

        String accion = request.getParameter("accion");

        if (accion == null) {
            accion = "listar";
        }

        switch (accion) {

        case "nuevo":

            request.setAttribute("libro", null);

            request.getRequestDispatcher(
                    "libro-formulario.jsp")
                    .forward(request, response);

            break;

        case "editar":

            int idEditar = Integer.parseInt(
                    request.getParameter("id"));

            Libro libro =
                    libroDAO.buscarPorId(idEditar);

            request.setAttribute("libro", libro);

            request.getRequestDispatcher(
                    "libro-formulario.jsp")
                    .forward(request, response);

            break;

        case "eliminar":

            int idEliminar = Integer.parseInt(
                    request.getParameter("id"));

            libroDAO.eliminar(idEliminar);

            response.sendRedirect("libros");

            break;

        default:

            List<Libro> libros = libroDAO.listar();

            request.setAttribute("libros", libros);

            request.getRequestDispatcher("libros.jsp")
                    .forward(request, response);

            break;
        }
    }

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String idTexto = request.getParameter("idLibro");
        String titulo = request.getParameter("titulo");
        String autor = request.getParameter("autor");

        boolean disponible = Boolean.parseBoolean(
                request.getParameter("disponible"));

        Libro libro = new Libro();

        libro.setTitulo(titulo);
        libro.setAutor(autor);
        libro.setDisponible(disponible);

        if (idTexto == null || idTexto.isBlank()) {

            libroDAO.insertar(libro);

        } else {

            libro.setIdLibro(Integer.parseInt(idTexto));
            libroDAO.actualizar(libro);
        }

        response.sendRedirect("libros");
    }
}