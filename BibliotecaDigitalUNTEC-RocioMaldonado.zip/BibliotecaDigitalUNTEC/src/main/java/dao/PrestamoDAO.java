package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.Prestamo;
import util.ConexionBD;

public class PrestamoDAO {

    public List<Prestamo> listar() {

        List<Prestamo> prestamos = new ArrayList<>();

        String sql = "SELECT p.*, u.nombre, l.titulo "
                + "FROM prestamos p "
                + "INNER JOIN usuarios u "
                + "ON p.id_usuario = u.id_usuario "
                + "INNER JOIN libros l "
                + "ON p.id_libro = l.id_libro "
                + "ORDER BY p.id_prestamo DESC";

        try {
            Connection conexion = ConexionBD.getConexion();

            PreparedStatement sentencia =
                    conexion.prepareStatement(sql);

            ResultSet resultado = sentencia.executeQuery();

            while (resultado.next()) {

                Prestamo prestamo = new Prestamo();

                prestamo.setIdPrestamo(
                        resultado.getInt("id_prestamo"));

                prestamo.setIdUsuario(
                        resultado.getInt("id_usuario"));

                prestamo.setIdLibro(
                        resultado.getInt("id_libro"));

                prestamo.setFechaPrestamo(
                        resultado.getDate("fecha_prestamo"));

                prestamo.setFechaDevolucion(
                        resultado.getDate("fecha_devolucion"));

                prestamo.setEstado(
                        resultado.getString("estado"));

                prestamo.setNombreUsuario(
                        resultado.getString("nombre"));

                prestamo.setTituloLibro(
                        resultado.getString("titulo"));

                prestamos.add(prestamo);
            }

            resultado.close();
            sentencia.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return prestamos;
    }

    public boolean registrar(
            int idUsuario, int idLibro) {

        String insertar = "INSERT INTO prestamos "
                + "(id_usuario, id_libro, fecha_prestamo, estado) "
                + "VALUES (?, ?, CURDATE(), 'PRESTADO')";

        String actualizarLibro = "UPDATE libros "
                + "SET disponible = FALSE "
                + "WHERE id_libro = ?";

        try {
            Connection conexion = ConexionBD.getConexion();

            PreparedStatement sentencia =
                    conexion.prepareStatement(insertar);

            sentencia.setInt(1, idUsuario);
            sentencia.setInt(2, idLibro);

            int resultado = sentencia.executeUpdate();
            sentencia.close();

            if (resultado > 0) {

                PreparedStatement actualizar =
                        conexion.prepareStatement(
                                actualizarLibro);

                actualizar.setInt(1, idLibro);
                actualizar.executeUpdate();
                actualizar.close();

                return true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean devolver(
            int idPrestamo, int idLibro) {

        String devolver = "UPDATE prestamos "
                + "SET fecha_devolucion = CURDATE(), "
                + "estado = 'DEVUELTO' "
                + "WHERE id_prestamo = ?";

        String actualizarLibro = "UPDATE libros "
                + "SET disponible = TRUE "
                + "WHERE id_libro = ?";

        try {
            Connection conexion = ConexionBD.getConexion();

            PreparedStatement sentencia =
                    conexion.prepareStatement(devolver);

            sentencia.setInt(1, idPrestamo);

            int resultado = sentencia.executeUpdate();
            sentencia.close();

            if (resultado > 0) {

                PreparedStatement actualizar =
                        conexion.prepareStatement(
                                actualizarLibro);

                actualizar.setInt(1, idLibro);
                actualizar.executeUpdate();
                actualizar.close();

                return true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean eliminar(
            int idPrestamo, int idLibro) {

        String eliminar = "DELETE FROM prestamos "
                + "WHERE id_prestamo = ?";

        String actualizarLibro = "UPDATE libros "
                + "SET disponible = TRUE "
                + "WHERE id_libro = ?";

        try {
            Connection conexion = ConexionBD.getConexion();

            PreparedStatement sentencia =
                    conexion.prepareStatement(eliminar);

            sentencia.setInt(1, idPrestamo);

            int resultado = sentencia.executeUpdate();
            sentencia.close();

            if (resultado > 0) {

                PreparedStatement actualizar =
                        conexion.prepareStatement(
                                actualizarLibro);

                actualizar.setInt(1, idLibro);
                actualizar.executeUpdate();
                actualizar.close();

                return true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}
