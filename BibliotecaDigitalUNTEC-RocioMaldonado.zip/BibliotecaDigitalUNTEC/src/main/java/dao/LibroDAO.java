package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.Libro;
import util.ConexionBD;

public class LibroDAO {

    public List<Libro> listar() {

        List<Libro> libros = new ArrayList<>();

        String sql = "SELECT * FROM libros "
                + "ORDER BY id_libro";

        try {
            Connection conexion = ConexionBD.getConexion();

            PreparedStatement sentencia =
                    conexion.prepareStatement(sql);

            ResultSet resultado = sentencia.executeQuery();

            while (resultado.next()) {

                Libro libro = new Libro();

                libro.setIdLibro(
                        resultado.getInt("id_libro"));

                libro.setTitulo(
                        resultado.getString("titulo"));

                libro.setAutor(
                        resultado.getString("autor"));

                libro.setDisponible(
                        resultado.getBoolean("disponible"));

                libros.add(libro);
            }

            resultado.close();
            sentencia.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return libros;
    }

    public Libro buscarPorId(int idLibro) {

        String sql = "SELECT * FROM libros "
                + "WHERE id_libro = ?";

        try {
            Connection conexion = ConexionBD.getConexion();

            PreparedStatement sentencia =
                    conexion.prepareStatement(sql);

            sentencia.setInt(1, idLibro);

            ResultSet resultado = sentencia.executeQuery();

            if (resultado.next()) {

                Libro libro = new Libro();

                libro.setIdLibro(
                        resultado.getInt("id_libro"));

                libro.setTitulo(
                        resultado.getString("titulo"));

                libro.setAutor(
                        resultado.getString("autor"));

                libro.setDisponible(
                        resultado.getBoolean("disponible"));

                resultado.close();
                sentencia.close();

                return libro;
            }

            resultado.close();
            sentencia.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public boolean insertar(Libro libro) {

        String sql = "INSERT INTO libros "
                + "(titulo, autor, disponible) "
                + "VALUES (?, ?, ?)";

        try {
            Connection conexion = ConexionBD.getConexion();

            PreparedStatement sentencia =
                    conexion.prepareStatement(sql);

            sentencia.setString(1, libro.getTitulo());
            sentencia.setString(2, libro.getAutor());
            sentencia.setBoolean(3, libro.isDisponible());

            int filas = sentencia.executeUpdate();
            sentencia.close();

            return filas > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean actualizar(Libro libro) {

        String sql = "UPDATE libros SET "
                + "titulo = ?, autor = ?, disponible = ? "
                + "WHERE id_libro = ?";

        try {
            Connection conexion = ConexionBD.getConexion();

            PreparedStatement sentencia =
                    conexion.prepareStatement(sql);

            sentencia.setString(1, libro.getTitulo());
            sentencia.setString(2, libro.getAutor());
            sentencia.setBoolean(3, libro.isDisponible());
            sentencia.setInt(4, libro.getIdLibro());

            int filas = sentencia.executeUpdate();
            sentencia.close();

            return filas > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean eliminar(int idLibro) {

        String sql = "DELETE FROM libros "
                + "WHERE id_libro = ?";

        try {
            Connection conexion = ConexionBD.getConexion();

            PreparedStatement sentencia =
                    conexion.prepareStatement(sql);

            sentencia.setInt(1, idLibro);

            int filas = sentencia.executeUpdate();
            sentencia.close();

            return filas > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}