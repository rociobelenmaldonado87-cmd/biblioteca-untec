package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import model.Usuario;
import util.ConexionBD;

public class UsuarioDAO {

    public Usuario validarUsuario(
            String correo, String clave) {

        String sql = "SELECT * FROM usuarios "
                + "WHERE correo = ? AND clave = ?";

        try {
            Connection conexion = ConexionBD.getConexion();

            PreparedStatement sentencia =
                    conexion.prepareStatement(sql);

            sentencia.setString(1, correo);
            sentencia.setString(2, clave);

            ResultSet resultado = sentencia.executeQuery();

            if (resultado.next()) {

                Usuario usuario = new Usuario();

                usuario.setIdUsuario(
                        resultado.getInt("id_usuario"));

                usuario.setNombre(
                        resultado.getString("nombre"));

                usuario.setCorreo(
                        resultado.getString("correo"));

                usuario.setClave(
                        resultado.getString("clave"));

                resultado.close();
                sentencia.close();

                return usuario;
            }

            resultado.close();
            sentencia.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
}