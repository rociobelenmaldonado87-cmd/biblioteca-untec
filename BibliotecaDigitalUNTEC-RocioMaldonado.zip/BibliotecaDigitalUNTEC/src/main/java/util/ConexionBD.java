package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

    private static final String URL =
            "jdbc:mysql://localhost:3306/biblioteca_untec"
            + "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";

    private static final String USUARIO = "biblioteca_user";
    private static final String CLAVE = "Biblioteca123!";

    private static Connection conexion;

    private ConexionBD() {
    }

    public static Connection getConexion() throws SQLException {

        if (conexion == null || conexion.isClosed()) {

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(
                        "No se encontró el conector de MySQL.", e);
            }

            conexion = DriverManager.getConnection(
                    URL, USUARIO, CLAVE);
        }

        return conexion;
    }
}